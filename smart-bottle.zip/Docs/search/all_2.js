var searchData=
[
  ['drdy_5fgpio_0',['drdy_gpio',['../struct_a_d_s1115settings.html#a2ec35347e84e5165a35191e670c05b79',1,'ADS1115settings']]],
  ['drinkable_1',['drinkable',['../class_j_s_o_n_c_g_i_a_d_c_callback.html#a6b248127dfab55a1c3371914c270e452',1,'JSONCGIADCCallback']]]
];
