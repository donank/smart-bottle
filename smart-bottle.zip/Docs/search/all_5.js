var searchData=
[
  ['get_0',['get',['../classcircularbuffer.html#a70cefd117afb0511bfeabdc67b13b6c7',1,'circularbuffer']]],
  ['getads1115settings_1',['getADS1115settings',['../class_a_d_s1115rpi.html#ad8f096a3061f19cda469efe0eee60510',1,'ADS1115rpi']]],
  ['getjsonstring_2',['getJSONString',['../class_j_s_o_n_c_g_i_a_d_c_callback.html#a763ae66809e399f49e712a1ad68289bb',1,'JSONCGIADCCallback']]],
  ['getsamplingrate_3',['getSamplingRate',['../struct_a_d_s1115settings.html#ab4314bdcd3638815129e97458ca43950',1,'ADS1115settings']]],
  ['gettemperature_4',['getTemperature',['../classtemperature.html#a3a64c2e2f353d770a43e705f040284bd',1,'temperature']]],
  ['gettype_5',['getType',['../classph.html#a01175e81f1ece138433ce455f576e1db',1,'ph::getType()'],['../classtemperature.html#af2455be872c80646d98f742393f085cc',1,'temperature::getType()'],['../classturbidity.html#a095ff8fab209fa61ef969060e2bd5494',1,'turbidity::getType()']]]
];
