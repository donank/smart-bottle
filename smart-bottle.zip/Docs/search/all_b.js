var searchData=
[
  ['samplingrate_0',['samplingRate',['../struct_a_d_s1115settings.html#aab5ef57bb9aef08aac7a7fd7de33a451',1,'ADS1115settings']]],
  ['samplingrates_1',['SamplingRates',['../struct_a_d_s1115settings.html#aa3a33d5f6c7f14bb708a70499a225357',1,'ADS1115settings']]],
  ['sensor_2',['sensor',['../classsensor.html',1,'']]],
  ['sensorfastcgivm_3',['sensorfastcgivm',['../class_s_e_n_s_o_r_p_o_s_t_callback.html#adc832aa5b751e9417746ee651f0db4ac',1,'SENSORPOSTCallback']]],
  ['sensorpostcallback_4',['SENSORPOSTCallback',['../class_s_e_n_s_o_r_p_o_s_t_callback.html',1,'']]],
  ['setchannel_5',['setChannel',['../class_a_d_s1115rpi.html#a4f36d0cca6cbec106b5a626d9973e091',1,'ADS1115rpi']]],
  ['settemperature_6',['setTemperature',['../classtemperature.html#a1174c472a0f04dc1923a0a74b9ba4af3',1,'temperature']]],
  ['settype_7',['setType',['../classph.html#a6796ebdb1f1157dea0032b65614217ec',1,'ph::setType()'],['../classtemperature.html#a12eed927e0898093c832cbcc273d77d9',1,'temperature::setType()'],['../classturbidity.html#a2aafc8b6b8ee10af0c43000a3dff34eb',1,'turbidity::setType()']]],
  ['size_8',['size',['../classcircularbuffer.html#ae17663b3c5559f08d455c5c108dd47c9',1,'circularbuffer']]],
  ['start_9',['start',['../class_a_d_s1115rpi.html#a401e626b6afed688a9b0518c0316b2a9',1,'ADS1115rpi::start()'],['../class_cpp_thread.html#a1be46d1be000f41a763289300623c609',1,'CppThread::start()']]],
  ['stop_10',['stop',['../class_a_d_s1115rpi.html#a910b9735f8bef69a0844a821fda06baf',1,'ADS1115rpi']]]
];
