var searchData=
[
  ['pga_0',['PGA',['../struct_a_d_s1115settings.html#a831970032a15754ead970931dd25ac5f',1,'ADS1115settings']]]
];
