var searchData=
[
  ['samplingrates_0',['SamplingRates',['../struct_a_d_s1115settings.html#aa3a33d5f6c7f14bb708a70499a225357',1,'ADS1115settings']]]
];
