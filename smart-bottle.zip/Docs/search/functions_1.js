var searchData=
[
  ['drinkable_0',['drinkable',['../class_j_s_o_n_c_g_i_a_d_c_callback.html#a6b248127dfab55a1c3371914c270e452',1,'JSONCGIADCCallback']]]
];
