var searchData=
[
  ['full_0',['full',['../classcircularbuffer.html#a104b34c0e0d41081c36cade7644a40a0',1,'circularbuffer']]]
];
