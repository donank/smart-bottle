var searchData=
[
  ['samplingrate_0',['samplingRate',['../struct_a_d_s1115settings.html#aab5ef57bb9aef08aac7a7fd7de33a451',1,'ADS1115settings']]],
  ['sensorfastcgivm_1',['sensorfastcgivm',['../class_s_e_n_s_o_r_p_o_s_t_callback.html#adc832aa5b751e9417746ee651f0db4ac',1,'SENSORPOSTCallback']]]
];
